package com.cdac.valid;



import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cdac.dto.Admin;



@Service
public class AdminValidator  implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(Admin.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName","unmKey", "* email id required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userPass", "passKey","* password required");
		
		Admin admin = (Admin)target;
		if(admin.getUserPass()!=null) {
			if(admin.getUserPass().length()<4) { 
				errors.rejectValue("userPass", "passKey", "* password should contain at least 3 character");
			}
		}
		
		
	}

}

