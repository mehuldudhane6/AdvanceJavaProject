package com.cdac.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cdac.dto.Admin;
import com.cdac.dto.EmployeeReg;

@Service
public class EmpValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		 return clazz.equals(EmployeeReg.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		System.out.println("taai");
		System.out.println(target);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName","unmKey", " username required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "gmail", "gmKey", " password required");
		
		EmployeeReg  emp= (EmployeeReg)target;
		if(emp.getGmail()!=null) {
			if(emp.getGmail().length()<4) { 
				errors.rejectValue("gmail", "gmKey", "* password should contain at least 3 character");
			}
		}
		
	}

}
