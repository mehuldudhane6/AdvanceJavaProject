package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.EmployeeRecordDao;
import com.cdac.dto.Employee;

@Service
public class EmployeeRecordServiceImple implements EmployeeRecordService {
     @Autowired
	 EmployeeRecordDao empRecordDao;
	@Override
	public List<Employee> selectAll() {
		
		return empRecordDao.selectAll();
	}

}
