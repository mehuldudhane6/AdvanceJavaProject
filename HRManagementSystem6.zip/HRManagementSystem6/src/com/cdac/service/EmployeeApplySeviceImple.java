package com.cdac.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.EmployeeDao;
import com.cdac.dto.Employee;

@Service
public class EmployeeApplySeviceImple implements EmployeeApplyService {
    @Autowired
	private EmployeeDao employeeDao;
	@Override
	public void add(Employee employee) {
		  employeeDao.insert(employee);

	}

}
