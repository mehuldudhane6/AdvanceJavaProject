package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.EmployeePendingDao;
import com.cdac.dao.EmployeeRecordDao;
import com.cdac.dto.Employee;
import com.cdac.dto.LeaveAppl;

@Service
public class EmployeePendingServiceImple implements EmployeePendingService {
     @Autowired
	 EmployeePendingDao empPendingDao;
	@Override
	public List<Employee> selectAll() {
		
		return empPendingDao.selectAll();
	}
	@Override
	public void removeRecord(int empId) {
		 empPendingDao.deleteRecord(empId);
		
	}
	@Override
	public Employee updateRecord(int empId) {
		return empPendingDao.modify(empId);
		
	}
	@Override
	public void updateEmployeeRecord(Employee emp) {
		empPendingDao.modifyEmp(emp);
		
	}
	@Override
	public void blockAccount(Employee emp) {
		 empPendingDao.BlockAccountDetails(emp);
		
	}
	@Override
	public List<Employee> historyInfo() {
		
		return  empPendingDao.historyInfo();
	}
	@Override
	public LeaveAppl manageLeave(int empId) {
		
		return empPendingDao.manageLeave(empId);
	}
	@Override
	public void updateLeaveStatus(LeaveAppl leave) {
		empPendingDao.updateLeaveStatus(leave);
		
	}
	
	

}
