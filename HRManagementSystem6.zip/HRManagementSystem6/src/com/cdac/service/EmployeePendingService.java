package com.cdac.service;

import java.util.List;

import com.cdac.dto.Employee;
import com.cdac.dto.LeaveAppl;



public interface EmployeePendingService {
	List<Employee> selectAll();
	void removeRecord(int empId);
	Employee updateRecord(int empId);
	void updateEmployeeRecord(Employee emp);
	void blockAccount(Employee emp);
	List<Employee> historyInfo();
	LeaveAppl manageLeave(int empId);
	void updateLeaveStatus(LeaveAppl leave);
}
