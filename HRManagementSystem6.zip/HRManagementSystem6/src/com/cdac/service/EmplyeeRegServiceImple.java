package com.cdac.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.EmployeeRegDao;
import com.cdac.dto.EmployeeReg;

@Service
public class EmplyeeRegServiceImple implements EmployeeRegService {
    @Autowired
	private EmployeeRegDao empRegDao;
	@Override
	public void addUser(EmployeeReg emp) {
		  empRegDao.registerUser(emp);

	}
	@Override
	public boolean checkUser(EmployeeReg emp) {
		
		return empRegDao.validateUser(emp);
	}
	@Override
	public boolean checkNewUser(EmployeeReg emp) {
		
		return empRegDao.checkNewUser(emp);
	}
	
	@Override
	public String forgotPassword(String gmail) {
		return empRegDao.forgotPassword(gmail);
	}

}
