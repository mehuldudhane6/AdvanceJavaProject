package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.LeaveDao;
import com.cdac.dto.LeaveAppl;

@Service
public class LeaveServiceImple implements LeaveService {
	@Autowired
    private LeaveDao leaveDao;
	@Override
	public void leaveApply(LeaveAppl leaveApply) {
		  leaveDao.leaveApply(leaveApply);

	}
	@Override
	public List<LeaveAppl> selectAll(){
		return leaveDao.selectAll();
	}
	@Override
	public void deleteLeaveRequest(int leaveId) {
		
		leaveDao.deleteLeaveReques(leaveId);
	}

}
