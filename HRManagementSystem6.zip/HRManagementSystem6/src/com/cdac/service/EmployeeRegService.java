package com.cdac.service;

import com.cdac.dto.EmployeeReg;

public interface EmployeeRegService {
         void addUser(EmployeeReg emp);
         boolean checkUser(EmployeeReg emp);
         boolean checkNewUser(EmployeeReg emp);
         String forgotPassword(String gmail);
}
