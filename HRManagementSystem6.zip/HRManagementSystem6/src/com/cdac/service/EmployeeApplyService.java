package com.cdac.service;

import com.cdac.dto.Employee;

public interface EmployeeApplyService {
      void add(Employee employee);
}
