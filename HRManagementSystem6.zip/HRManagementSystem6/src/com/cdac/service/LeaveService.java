package com.cdac.service;

import java.util.List;

import com.cdac.dto.LeaveAppl;

public interface LeaveService {
	 void leaveApply(LeaveAppl leaveApply);
	 List<LeaveAppl> selectAll();
	 void deleteLeaveRequest(int leaveId);
}
