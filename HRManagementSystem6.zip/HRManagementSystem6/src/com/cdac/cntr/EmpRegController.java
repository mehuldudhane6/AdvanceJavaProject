package com.cdac.cntr;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.EmployeeReg;
import com.cdac.service.EmployeeRegService;

@Controller
public class EmpRegController {
      @Autowired
	  private EmployeeRegService employeeRegService;
      @Autowired
      private MailSender mailSender;
      @RequestMapping(value="/prep_reg_form.htm",method=RequestMethod.GET)
      String preRegForm(ModelMap map) {
    	  map.put("empReg", new EmployeeReg());
    	  return "prep_reg_form"; 
      }
      
      @RequestMapping(value="/register1.htm",method=RequestMethod.POST)
      public String register(EmployeeReg emp,ModelMap map,HttpSession session) {
  		boolean check = employeeRegService.checkNewUser(emp);
  		if(check)
  		{
  			
  			session.setAttribute("check1",check);
  			return "prep_reg_form";
  		}else {
  			 employeeRegService.addUser(emp);
  			return "applicant";
  		}
  	}
      
      @RequestMapping(value = "/back.htm" , method = RequestMethod.GET)
  	public String newIndex(ModelMap map , HttpSession session) {
  		session.invalidate();
  		return "home";
  	}

   
      
      @RequestMapping(value = "/forgot_password.htm",method = RequestMethod.POST)
  	public String forgotPassword(@RequestParam String gmail,ModelMap map) {		
  		String pass = employeeRegService.forgotPassword(gmail);
  		String link="http://localhost:8080/HRManagementSystem/employee_Login.htm?email="+gmail; 		
  		String msg = "you are not registered";
  		if(pass!=null) {	
  			
  			SimpleMailMessage message = new SimpleMailMessage();  
  	        message.setFrom("mehuldudhane6@gmail.com");  
  	        message.setTo(gmail);  
  	        message.setSubject("Your password");  
  	        message.setText(link);  
  	        //sending message   
  	        mailSender.send(message);
  			msg = "check the mail for password";
  		}
  		map.put("msg", msg);
  		return "info";
  	}
      
      
}
