package com.cdac.cntr;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdac.dto.Employee;
import com.cdac.dto.EmployeeReg;
import com.cdac.dto.LeaveAppl;
import com.cdac.service.EmployeeApplyService;
import com.cdac.service.EmployeeRegService;
import com.cdac.service.LeaveService;
import com.cdac.valid.EmpValidator;


@Controller
public class EmpController {
    	 @Autowired
         private EmployeeApplyService empApplyService;
         @Autowired
         private LeaveService leaveService;
         @Autowired  
    	 private EmployeeRegService empRegService;
         @Autowired
         private  EmpValidator empValidator;
    	@RequestMapping(value="/pre_apply_from.htm",method=RequestMethod.GET)
    	String preApplyForm(Employee emp,ModelMap map) {
    		 map.put("empApply", new Employee("pending","user"));
    		return "apply_form";
    	}
    	
    	@RequestMapping(value="applyform.htm", method=RequestMethod.POST)
    	String applyForms(Employee employee,ModelMap map)
    	{
    		empApplyService.add(employee);
    		return "postApply";
    	}
    	
    	@RequestMapping(value="/employee_Login.htm",method=RequestMethod.GET)
    	public String checkLogin(ModelMap map) {
    		map.put("empReg", new EmployeeReg());
    		return "employee_login_form";
    	}
    	
    	@RequestMapping(value="/validate_employee_form.htm",method=RequestMethod.POST)
    	public String validateUser(EmployeeReg empp, BindingResult result,ModelMap map,HttpSession session) {
    		empValidator.validate(empp, result);
    		System.out.println("baba");
    		if(result.hasErrors())
    		{
    			System.out.println("aaai");
    			map.put("empReg", new EmployeeReg());
    			return "employee_login_form";
    		}
    		boolean t=empRegService.checkUser(empp);
    		if(t)
    		{
    			session.setAttribute("emp",empp);
    			return "empHome";
    		}
    		else {
    			session.setAttribute("emp", t);
    			map.put("empReg", new EmployeeReg());
    			return "employee_login_form";
    		}
    	}
    	
    	@RequestMapping(value="/preleaveRequest.htm",method=RequestMethod.GET)
         public String preLeaveApplivation(ModelMap map) {
    		          map.put("leave", new LeaveAppl());
    		         return "pre_leaveRequest_form";
   	            }
    	
    	@RequestMapping(value="/postleaveform.htm",method=RequestMethod.POST)
  	    public String postLeaveForm(LeaveAppl leaveAppl,HttpSession session) {
    		int emId=((EmployeeReg)session.getAttribute("emp")).getEmpId();
    		leaveAppl.setEmpId(emId);
   		    leaveAppl.setStatus("pending");
   		    //leaveAppl.setTotalLeave(10);
    		leaveService.leaveApply(leaveAppl);
    		return "leaveSuccess";
    	}
}
