package com.cdac.cntr;

import java.time.LocalDate;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.Admin;
import com.cdac.dto.Employee;
import com.cdac.dto.LeaveAppl;
import com.cdac.service.AdminService;
import com.cdac.service.EmployeePendingService;
import com.cdac.service.EmployeeRecordService;
import com.cdac.service.LeaveService;
import com.cdac.valid.AdminValidator;

@Controller
public class AdminController {
	  @Autowired
      private AdminService adminService;
	  @Autowired
  	  private EmployeeRecordService employeeRecordService;
	 
	  @Autowired
	  private EmployeePendingService empPendingService;
	  @Autowired
      private LeaveService leaveService;
	  @Autowired
	  private AdminValidator adminValidator;
	@RequestMapping(value="/prep_admin_form.htm", method=RequestMethod.GET)
	public String prepAdminForm(ModelMap map) {
		map.put("adminform", new Admin());
		return "admin_form";
		
	} 
	
	@RequestMapping(value="/validate_admin_form.htm", method=RequestMethod.POST)
	public String validateUser(Admin admin ,BindingResult result, ModelMap map ,HttpSession session)
	{
		adminValidator.validate(admin, result);
		if(result.hasErrors())
		{
			return "admin_form";
		}
		boolean t=adminService.validateAdmin(admin);
		if(t)
		{
			session.setAttribute("admin", admin);
			return "hr_home";
		}
		else {
			session.setAttribute("admin", t);

			return "admin_form";
		}
		
	}
	
	@RequestMapping(value="/old_employee.htm", method=RequestMethod.GET)
	public String displayOldEmployee(ModelMap map) {
		List<Employee> li=employeeRecordService.selectAll();
		map.put("empList", li);
		return "employeeList";
	}
	
	
	 
	 @RequestMapping(value="/pendingList.htm", method=RequestMethod.GET)
		public String displayPendingList(ModelMap map) {
			List<Employee> li=empPendingService.selectAll();
			map.put("empList1", li);
			return "employeePendingList";
		}
	
	@RequestMapping(value="/emp_delete.htm" ,method=RequestMethod.GET)
	 public String deleteApply(@RequestParam int empId,ModelMap map) {
		empPendingService.removeRecord(empId);
		List<Employee> li=empPendingService.selectAll();
		map.put("empList1", li);
		return "employeePendingList";
		 
	 }
	
	
	
	@RequestMapping(value="/emp_approve.htm" ,method=RequestMethod.GET)
	 public String approveApply(@RequestParam int empId,ModelMap map,HttpSession session) {
		session.setAttribute("emp", empId);
		System.out.println(empId);
		Employee emp=empPendingService.updateRecord(empId);
		emp.setStatus("approved");
		System.out.println("mehul"+emp.getEmpId());
		map.put("empList1", emp);
		return "approved_form";
		 
	 }
	
	@RequestMapping(value="/updateSalaryDetails.htm",method=RequestMethod.POST)
	public String updateSalaryDetails1(Employee emp, ModelMap map) {
		System.out.println("after"+emp.getEmpId());
		 empPendingService.updateEmployeeRecord(emp);
	   return "hr_home";	
	}
	
	@RequestMapping(value="/emp_block.htm",method=RequestMethod.GET)
	public String empBlockAccount(@RequestParam int empId,ModelMap map,HttpSession session)
	{
		session.setAttribute("emp", empId);
		System.out.println(empId);
		Employee emp=empPendingService.updateRecord(empId);
		System.out.println("mehul"+emp.getEmpId());
		emp.setStatus("Blocked");
		map.put("eList", emp);
		return "Blocked_form";
	}
	

	@RequestMapping(value="/employee_block_update.htm",method=RequestMethod.POST)
	public String updateBlockedState(Employee emp, ModelMap map) {
		int currentYear=LocalDate.now().getYear();
		System.out.println(currentYear);
		int joiningYear=Integer.parseInt(emp.getJoiningDate());
		int diff=currentYear-joiningYear;
		if(diff>4)
		{
			float pf=(emp.getSalary()*0.12f*12.0f*diff)+25000;
		    emp.setSalary(pf);
			
	    }
		else{
			float pf=(emp.getSalary()*0.12f*12.0f);
		    emp.setSalary(pf);
		}
		System.out.println("after"+emp.getEmpId());
		 empPendingService.updateEmployeeRecord(emp);
		 List<Employee> li=employeeRecordService.selectAll();
			map.put("empList", li);
			return "employeeList";	
	}
	
	
	
	@RequestMapping(value="/history_List.htm",method=RequestMethod.GET)
	public String historyList(ModelMap map) {
		List<Employee> li=empPendingService.historyInfo();
		map.put("elist", li);
		return "History_List";
	}
	
	@RequestMapping(value="/emp_manage.htm",method=RequestMethod.GET)
	public String mangeEmployeeRecords(@RequestParam int empId,ModelMap map,HttpSession session) {
		Employee emp=empPendingService.updateRecord(empId);
		map.put("empLi", emp);
		return "manage_record";
	}
	
	@RequestMapping(value="employeeManagement.htm",method=RequestMethod.POST)
	public String updateSalaryInfo(Employee emp) {
		 empPendingService.updateEmployeeRecord(emp);
		   return "hr_home";	
	}
	
	@RequestMapping(value="/employee_LeaveList.htm",method=RequestMethod.GET)
	public String employeeLeaveList(ModelMap map) {
		List<LeaveAppl> li=leaveService.selectAll();
		map.put("leaveList", li);
		return "manageLeave";
	}
	
	@RequestMapping(value="/leave_request_delete.htm",method=RequestMethod.GET)
	public String deleteLeaveRequest(@RequestParam int leaveId,ModelMap map) {
		System.out.println(leaveId);
		leaveService.deleteLeaveRequest(leaveId);
		List<LeaveAppl> li=leaveService.selectAll();
		map.put("leaveList", li);
		return "manageLeave";
	}
	
	@RequestMapping(value="/emp_approve_leave.htm")
	public String leaveEmpIfo(@RequestParam int empId,ModelMap map) {
		Employee emp=empPendingService.updateRecord(empId);
		map.put("emp", emp);
		 return "leaveEmpInfo";
	}
	
	
	@RequestMapping(value="emp_accept_leave.htm")
	public String acceptLeave(@RequestParam int empId,ModelMap map)
	{
		System.out.println("mehul"+empId);
		LeaveAppl leave=empPendingService.manageLeave(empId);
		System.out.println(leave.getLeaveId());
		int balanceLeave=leave.getPendingleave();
		System.out.println(balanceLeave);
		if(balanceLeave>0)
		{
			int x=balanceLeave-1;
			leave.setPendingleave(x);
			empPendingService.updateLeaveStatus(leave);
			return "leaveApproval";
		}
		else {
			return "hr_home";
		}
		
		
	}
	
	@RequestMapping(value="/logoutProcess.htm",method=RequestMethod.GET)
	public String logoutprocess() {
		return "logout";
	}
	
}
