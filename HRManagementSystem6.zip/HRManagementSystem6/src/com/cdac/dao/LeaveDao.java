package com.cdac.dao;

import java.util.List;

import com.cdac.dto.LeaveAppl;

public interface LeaveDao {
      void leaveApply(LeaveAppl leaveApply);
      List<LeaveAppl> selectAll();
      void deleteLeaveReques(int leaveId);
}
