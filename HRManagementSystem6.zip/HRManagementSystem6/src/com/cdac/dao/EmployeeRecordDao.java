package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Employee;



public interface EmployeeRecordDao {
	List<Employee> selectAll();
}
