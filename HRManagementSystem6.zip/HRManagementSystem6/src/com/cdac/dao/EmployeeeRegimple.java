package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.Admin;
import com.cdac.dto.EmployeeReg;


@Repository
public class EmployeeeRegimple implements EmployeeRegDao {
    @Autowired
	private HibernateTemplate hibernateTemplate;
	@Override
	public void registerUser(EmployeeReg emp) {
		   hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr=session.beginTransaction();
				session.save(emp);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});
	}
	@Override
	public boolean validateUser(EmployeeReg emp) {
		boolean b= hibernateTemplate.execute(new HibernateCallback<Boolean>() {

			@Override
			public Boolean doInHibernate(Session session) throws HibernateException {
				Transaction tr=session.beginTransaction();
				Query q=session.createQuery("from EmployeeReg where user_name=? and gmail=?");
				q.setString(0, emp.getUserName());
				q.setString(1, emp.getGmail());
				List<EmployeeReg> li=q.list();
				System.out.println(li);
				boolean flag=!li.isEmpty();
				if(flag==true)
				{
					emp.setEmpId(li.get(0).getEmpId());
				}
				tr.commit();
				session.flush();
				session.close();
				return flag;
			}
		});
		return b;
	}
	
	@Override
	public boolean checkNewUser(EmployeeReg emp) {
		boolean b = hibernateTemplate.execute(new HibernateCallback<Boolean>() {

			@Override
			public Boolean doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from EmployeeReg where user_name = ? ");
				q.setString(0, emp.getUserName());
	
				List<EmployeeReg> li = q.list();
				
				boolean flag = !li.isEmpty();
								
				tr.commit();
				session.flush();
				session.close();
				
				return flag;
			}
			
		});
		return b;
	}
	@Override
	public String forgotPassword(String gmail) {
		String password = hibernateTemplate.execute(new HibernateCallback<String>() {

			@Override
			public String doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from EmployeeReg where gmail = ?");
				q.setString(0, gmail);
				List<EmployeeReg> li = q.list();
				String pass = null;
				if(!li.isEmpty())
					pass = li.get(0).getGmail();
				tr.commit();
				session.flush();
				session.close();
				return pass;
			}
			
		});
		return password;
	}



}
