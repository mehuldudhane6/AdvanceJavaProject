package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.Employee;
import com.cdac.dto.LeaveAppl;



@Repository
public class EmployeePendingDaoImple implements EmployeePendingDao {
     
	 @Autowired
	 private HibernateTemplate hibernateTemplate;
	@Override
	public List<Employee> selectAll() {
		List<Employee> empList = hibernateTemplate.execute(new HibernateCallback<List<Employee>>() {

			@Override
			public List<Employee> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Employee where status='pending'");
				List<Employee> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return empList;
}
	@Override
	public void deleteRecord(int empId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new Employee(empId));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}
	@Override
	public Employee modify(int empId) {
		
		Employee emp=hibernateTemplate.execute(new HibernateCallback<Employee>() {

			@Override
			public Employee doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Employee em = (Employee)session.get(Employee.class,empId);
				System.out.println("=="+em.getEmpId());
				tr.commit();
				session.flush();
				session.close();
				return em;
			}
			
		});
		return emp;
	}
	@Override
	public void modifyEmp(Employee emp) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				System.out.println(emp.getEmpId());
				session.update(emp);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}
	
	@Override
	public void BlockAccountDetails(Employee emp) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.update(emp);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}
	@Override
	public List<Employee> historyInfo() {
		List<Employee> empList = hibernateTemplate.execute(new HibernateCallback<List<Employee>>() {

			@Override
			public List<Employee> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Employee where status='Blocked'");
				List<Employee> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return empList;
	}
	@Override
	public LeaveAppl manageLeave(int empId) {
		LeaveAppl leave=hibernateTemplate.execute(new HibernateCallback<LeaveAppl>() {

			@Override
			public LeaveAppl doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				System.out.println("minal");
				Query q=session.createQuery("from LeaveAppl where empId=?");
				q.setInteger(0, empId);
				List<LeaveAppl> li=q.list();
				LeaveAppl em=li.get(0);
				System.out.println("aajibai");
				tr.commit();
				session.flush();
				session.close();
				return em;
			}
			
		});
		return leave;
	}
	@Override
	public void updateLeaveStatus(LeaveAppl leave) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.update(leave);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}
}
