package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Employee;
import com.cdac.dto.LeaveAppl;

public interface EmployeePendingDao {
	List<Employee> selectAll();
	void deleteRecord(int empId);
	Employee modify(int empId);
	void modifyEmp(Employee emp);
	void BlockAccountDetails(Employee emp );
	List<Employee> historyInfo();
	LeaveAppl manageLeave(int empId);
	void updateLeaveStatus(LeaveAppl leave);
}
