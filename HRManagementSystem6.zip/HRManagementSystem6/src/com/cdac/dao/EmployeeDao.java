package com.cdac.dao;

import com.cdac.dto.Employee;

public interface EmployeeDao {
       void insert(Employee employee);
}
