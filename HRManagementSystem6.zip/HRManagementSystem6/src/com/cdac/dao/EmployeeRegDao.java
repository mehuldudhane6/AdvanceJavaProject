package com.cdac.dao;

import com.cdac.dto.EmployeeReg;

public interface EmployeeRegDao {
      void registerUser(EmployeeReg emp);
      boolean validateUser(EmployeeReg emp);
      boolean checkNewUser(EmployeeReg emp);
      String forgotPassword(String gmail);
}
