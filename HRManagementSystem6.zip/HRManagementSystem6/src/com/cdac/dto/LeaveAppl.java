package com.cdac.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="leave_req")
public class LeaveAppl {
	
      private int empId;
      @Id
      @GeneratedValue
      private int leaveId;
      private String leaveType;
      private String description;
      private String startDate;
      private String endDate;
      private int noOfDays;
      private String status;
      private int totalLeave=10;
      private int pendingleave=10;
      
      
      
   
	public int getTotalLeave() {
		return totalLeave;
	}
	public void setTotalLeave(int totalLeave) {
		this.totalLeave = totalLeave;
	}
	public int getPendingleave() {
		return pendingleave;
	}
	public void setPendingleave(int pendingleave) {
		this.pendingleave = pendingleave;
	}
	public LeaveAppl(int leaveId) {
		super();
		this.leaveId = leaveId;
	}
	public LeaveAppl() {
		super();
		
	}
	public LeaveAppl(int empId, String leaveType, String description, String startDate, String endDate, int noOfDays,
			String status) {
		super();
		this.empId = empId;
		this.leaveType = leaveType;
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		this.noOfDays = noOfDays;
		this.status = status;
	}
	
	
	public int getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getLeaveType() {
		return leaveType;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
      
      
}
