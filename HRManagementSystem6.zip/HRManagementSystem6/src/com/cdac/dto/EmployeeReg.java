package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;

@Entity
@Table(name="Employee_Regi")
public class EmployeeReg {
	@Id
	@GeneratedValue
	@Column(name="emp_id")
    private int empId;
	@Column(name="user_name")
    private String userName;
	@Column(name="gmail")
    private String gmail;
    private String role;

	public String getGmail() {
		return gmail;
	}

	public void setGmail(String gmail) {
		this.gmail = gmail;
	}

	public EmployeeReg() {
		super();
		
	}
	
	public EmployeeReg(String role) {
		super();
		this.role = role;
	}

	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "EmployeeReg [empId=" + empId + ", userName=" + userName + ", gmail=" + gmail + ", role=" + role + "]";
	}
    
	
    
}
