package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="allEmp")
public class Employee {
   @Id
   @GeneratedValue
   @Column(name="emp_id")
   private int empId;
   @Column(name="emp_name")
   private String name;
   private String degree;
   
   private String specialisation;
   
   private int mobileNo;
   private String applyFor;
   private int experience;
   private String status;
   private String role;
   private float salary;
   private String joiningDate;
   
       
		
     
		public String getJoiningDate() {
	return joiningDate;
}





public void setJoiningDate(String joiningDate) {
	this.joiningDate = joiningDate;
}





		public Employee(int empId) {
	super();
	this.empId = empId;
}





		public float getSalary() {
	return salary;
}





public void setSalary(float salary) {
	this.salary = salary;
}





		public Employee(String status, String role) {
			super();
			this.status = status;
			this.role = role;
		}





		public Employee() {
			super();
			
		}
		
		
		




		public int getEmpId() {
			return empId;
		}
		public void setEmpId(int empId) {
			this.empId = empId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getDegree() {
			return degree;
		}
		public void setDegree(String degree) {
			this.degree = degree;
		}
		public String getSpecialisation() {
			return specialisation;
		}
		public void setSpecialisation(String specialisation) {
			this.specialisation = specialisation;
		}
		public int getMobileNo() {
			return mobileNo;
		}
		public void setMobileNo(int mobileNo) {
			this.mobileNo = mobileNo;
		}
		public String getApplyFor() {
			return applyFor;
		}
		public void setApplyFor(String applyFor) {
			this.applyFor = applyFor;
		}
		public int getExperience() {
			return experience;
		}
		public void setExperience(int experience) {
			this.experience = experience;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}


		public String getRole() {
			return role;
		}



		public void setRole(String role) {
			this.role = role;
		}
		
		
		   
   
   
}
